To run this code, append the 'code' folder to your sys.path.
You should run something like this in your blender console:

import sys
sys.path.append("/path/to/code")
import main
main.main()

main() assumes that a single object is selected and will run both ex7 and ex9 in the same execution.